import os
import sys
import filecmp
import yaml
import errors
from Naked.toolshed.shell import execute_rb,muterun_rb
from subprocess import call
def parse(n):
	name_ast = "parser_"+ n+".rb"
	r_ast = open(name_ast,"w")
	r_ast.write("require 'parser/current'\n")
	r_ast.write("require 'ast'\n")
	r_ast.write("require 'sxp'\n")
	r_ast.write("Parser::Builders::Default.emit_lambda = true\n")
	r_ast.write("Parser::Builders::Default.emit_procarg0 = true\n")
	r_ast.write("Parser::Builders::Default.emit_encoding = true\n")
	r_ast.write("Parser::Builders::Default.emit_index = true\n")
	r_ast.write("def flatten_hash(hash)\n hash.each_with_object({}) do |(k,v), h|\n	if k.is_a? Hash\nflatten_hash(k).map do |h_k,h_v|\nif(h.include?(h_k))\nh[h_k].push(h_v)\nh[h_k] = h[h_k].flatten\n	else\nh[h_k] = h_v\nend\nend\nelse\nif(h.include?(k))\nh[k].push(v)\nh[k] = h[k].flatten\nelse\nh[k] = [v]\nend\nend\nend\nend\n")
	r_ast.write("def browse_acc(node,res,line,column)\nif (node == nil)\nreturn\nelsif (node.class == Parser::AST::Node)\ntemp = node.to_s\ntemp = temp.delete(' ')\ntemp = temp.delete(\"\n\")\ntemp= temp.delete('(')\ntemp = temp.delete(')')\nnode.children.each do |n|\nchild = n.to_s\nchild = child.delete(' ')\nchild = child.delete(\"\\n\")\nchild = child.delete('(')\nchild = child.delete(')')\n	temp.slice!(child)\nend\nres[temp] = res[temp] = \"(\"+node.loc.line.to_s+\",\"+node.loc.column.to_s+\")\"\nbrowse_acc(node.children,res,node.loc.line,node.loc.column)\nelsif (node.class == Array)\nnode.each do |n|\nif n.class == Parser::AST::Node && n.loc.expression != nil\n		temp = {}\nbrowse_acc(n,temp,n.loc.line,n.loc.column)\nres[temp] = \"(\"+n.loc.line.to_s+\",\"+n.loc.column.to_s+\")\"\nelse\nres[n.to_s] = \"(\"+line.to_s+\",\"+column.to_s+\")\"\nend\nend\nelse\n	res[node.to_s] = \"(\"+line.to_s+\",\"+column.to_s+\")\"\nend\nend\n\ndef browse(node)\nres = {}\nbrowse_acc(node,res,-1,-1)\nreturn res\nend\n")
	r_ast.write("cur_folder = __dir__\n")
	r_ast.write("f =\"/"+n+".rb\"\n")
	r_ast.write("path = cur_folder + f\n")
	r_ast.write("code = File.read(path)\n")
	r_ast.write("ast = Parser::CurrentRuby.parse(code)\n")
	r_ast.write("res = browse(ast)\n")
	r_ast.write("res = flatten_hash(res).to_s.gsub! '=>',':'\n")
	r_ast.write("map_ast_"+n+" = File.new(cur_folder+\"/map_source_"+n+"\",\"w\")\n")
	r_ast.write("map_ast_"+n+".write(res)\n")
	r_ast.write("map_ast_"+n+".close\n")
	r_ast.write("ast_"+n+"= File.new(cur_folder+\"/ast_"+n+"\",\"w\")\n")
	r_ast.write("ast_"+n+".write(ast)\n")
	r_ast.write("ast_"+n+".close")
	r_ast.close()
	success = execute_rb("parser_"+n+".rb")
	if(not success):
		raise errors.type_check_errors("Error with creation of the parser ! Check your Ruby file")
