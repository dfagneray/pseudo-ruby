import ruby_sexpr_translator
import parser
import yaml

def translate(name,source):
	n = name.split('.')[0]
	parser.parse(n)
	r = ruby_sexpr_translator.RubySEXPRTranslator()
	return r.Test(n,source)

def translate_to_yaml(name,source):
	translation = translate(name,source)
	print(translation)
	noaliases = yaml.dumper.SafeDumper
	noaliases.ignore_aliases = lambda self, data: True
	return yaml.dump(translation,Dumper = noaliases)
